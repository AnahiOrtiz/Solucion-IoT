﻿namespace Practica8.Entidades
{
    public class Root
    {
        public List<Lectura> records { get; set; }
    }
}
