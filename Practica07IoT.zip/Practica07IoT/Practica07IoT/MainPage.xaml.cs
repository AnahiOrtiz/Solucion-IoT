﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using OpenNETCF.MQTT;
using System.Threading;

namespace Practica07IoT
{
    public partial class MainPage : ContentPage
    {
        //Objeto MQTT
        MQTTClient mqtt;
        string mensaje = "";
        List<string> MensajeList = new List<string>();
        public MainPage()
        {
            InitializeComponent();
        }
        private void btnConectar_Clicked(object sender, EventArgs e)
        {
            //Validaciones del servidor y del puerto
            if (string.IsNullOrEmpty(txtServidor.Text))
            {
                DisplayAlert("Error", "No se ha ingresado el servidor", "OK");
            }
            if (string.IsNullOrEmpty(txtPuerto.Text))
            {
                DisplayAlert("Error", "No se ha ingresado el puerto", "OK");
            }
            int puerto = 0;
            if (!int.TryParse(txtPuerto.Text, out puerto))
            {
                DisplayAlert("Error", "El puerto ingresado no es un número", "OK");
            }
            mqtt = new MQTTClient(txtServidor.Text, puerto);
            mqtt.Connect(txtCliente.Text);
            while (!mqtt.IsConnected)
            {
                Thread.Sleep(1000);
            }
            DisplayAlert("Conectado", "Conexión exitosa", "Ok");
            mqtt.Connected += Mqtt_Connected;
            mqtt.MessageReceived += Mqtt_MessageReceived;
            Device.StartTimer(TimeSpan.FromMilliseconds(200), () => {
                if (mqtt.IsConnected)
                {
                    if (mensaje != "")
                    {
                        MensajeList.Add(mensaje);
                        lstMensajes.ItemsSource = null;
                        lstMensajes.ItemsSource = MensajeList;
                        mensaje = "";
                    }
                }
                return true;
            });  
        }
        private void Mqtt_MessageReceived(string topic, QoS qos, byte[] payload)
        {
            mensaje = $"[{topic}]:{Encoding.UTF8.GetString(payload)}";
        }
        private void Mqtt_Connected(object sender, EventArgs e)
        {
            DisplayAlert("Correcto", "Se ha conectado de forma exitosa", "Éxito");
        }
        private void btnEncenderLed_Clicked(object sender, EventArgs e)
        {
            if (mqtt.IsConnected)
            {
                mqtt.Publish("Tarjeta", "L1", QoS.FireAndForget, false);
            }
        }
        private void bgnApagarLed_Clicked(object sender, EventArgs e)
        {
            if (mqtt.IsConnected)
            {
                mqtt.Publish("Tarjeta", "L0", QoS.FireAndForget, false);
            }
        }
        private void btnObtenerDatos_Clicked(object sender, EventArgs e)
        {
            if (mqtt.IsConnected)
            {
                mqtt.Subscriptions.Add(new Subscription("AppMovil"));
            }
        }
        private void btnGirarServo_Clicked(object sender, EventArgs e)
        {
            if (mqtt.IsConnected)
            {
                mqtt.Publish("Tarjeta", "s0", QoS.FireAndForget, false);
            }
        }
        private void btnGirarMotor_Clicked(object sender, EventArgs e)
        {
            if (mqtt.IsConnected)
            {
                mqtt.Publish("Tarjeta", "gira", QoS.FireAndForget, false);
            } 
        }
        private void btnGirarServo90_Clicked(object sender, EventArgs e)
        {
            if (mqtt.IsConnected)
            {
                mqtt.Publish("Tarjeta", "s90", QoS.FireAndForget, false);
            }
        }
    }
}